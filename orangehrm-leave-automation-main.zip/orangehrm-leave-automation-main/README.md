URL: [OrangeHRM Demo](https://opensource-demo.orangehrmlive.com/web/index.php/auth/login)  
        Username: Admin
        
        Password: admin123

--------------------------------------- Automation Testing -----------------------------------

      Language: Java  
      Automation Tool: Selenium WebDriver  
      Testing Framework: TestNG  
      Build Tool: Maven  
      Browser: Chrome

-------------------------------------  File Path --------------------------------------------

Find the code in the following file path.
    Go To: 
       eclipse-workspace/POM_Test--> src-->main/java/com/orangehrm/test-->OrangeHRMAutomation.java
       
